#include <stdio.h>
#include "Blinky.h"
#include "LPC17xx.h"                       
#include "GLCD.h"
#include "LED.h"
#include "Board_ADC.h" 
#include "KBD.h"

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0                      /* Uncomment to use the LCD */

// ITM Stimulus Port definitions for printf //////////////////
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

struct __FILE { int handle;  };
FILE __stdout;
FILE __stdin;

int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}

char text[10];
char text_l[10];

static volatile uint16_t AD_dbg;

uint16_t ADC_last;                      // Last converted value
extern uint8_t clock_ms;                // Import external variable from IRQ.c file

int main(void) {
  int32_t res;
  int32_t res2;
  uint32_t AD_sum   = 0U;
  uint32_t AD_cnt   = 0U;
  uint32_t AD_value = 0U;
  uint32_t AD_print = 0U;
	int i;

  LED_Init();                            // LED Initialization
  ADC_Initialize();                      // ADC Initialization

#ifdef __USE_LCD
  GLCD_Init();                           // Initialize graphical LCD (if enabled)

  GLCD_Clear(White);                     // Clear graphical LCD display
  GLCD_SetBackColor(Blue);
  GLCD_SetTextColor(Yellow);
  GLCD_DisplayString(0, 0, __FI, "COE718 Demo Hamza    ");
  GLCD_SetTextColor(White);
  GLCD_DisplayString(1, 0, __FI, "       Blinky.c     ");
  GLCD_DisplayString(2, 0, __FI, "  Turn pot for LEDs ");
  GLCD_SetBackColor(White);
  GLCD_SetTextColor(Blue);
  GLCD_DisplayString(6, 0, __FI, "Direction:            ");
#endif

  SysTick_Config(SystemCoreClock/100);   // Generate interrupt each 10 ms

 while (1) {  
		LED_Out(0);
	 LED_On(i);
	 // Loop forever
    res = ADC_GetValue();
    res2 = get_button();
    if (res != -1) {                     // If conversion has finished
      ADC_last = (uint16_t)res;

      AD_sum += ADC_last;                // Add AD value to sum
      if (++AD_cnt == 16U) {             // Average over 16 values
        AD_cnt = 0U;
        AD_value = AD_sum >> 4;          // Average divided by 16
        AD_sum = 0U;
      }
    }
    
    // Handle AD converter
  /*  if (AD_value != AD_print) {
      AD_print = AD_value;               // Get unscaled value for printout
      AD_dbg   = (uint16_t)AD_value;

      sprintf(text, "0x%04X", AD_value); // Format text for printout 
*/
		
#ifdef __USE_LCD
      GLCD_SetTextColor(Red);
      GLCD_DisplayString(6, 9, __FI, (unsigned char *)text); // Display analog value
      //GLCD_SetTextColor(Green);
      //GLCD_Bargraph(144, 7*24, 176, 20, (AD_value >> 2)); 
#endif

      // Handle joystick input
      switch (res2) {
        case KBD_SELECT:
					i = 1;
          GLCD_DisplayString(6, 9, __FI, "     "); // Clear previous text
         GLCD_DisplayString(6, 9, __FI, "Select");
					printf("select\n");
				  AD_dbg = 10000;
          LED_On(0);
          break;

        case KBD_LEFT:
					i =2;
         GLCD_DisplayString(6, 9, __FI, "     "); // Clear previous text
         GLCD_DisplayString(6, 9, __FI, "Left");
					printf("left\n");
				  AD_dbg = 15000;
          LED_On(2);
          break;

        case KBD_RIGHT:
					i =3;
          GLCD_DisplayString(6, 9, __FI, "     "); // Clear previous text
          GLCD_DisplayString(6, 9, __FI, "Right");
					printf("right\n");
				  AD_dbg = 20000;
          LED_On(3);
          break;

        case KBD_UP:
					i=4;
         GLCD_DisplayString(6, 9, __FI, "     "); // Clear previous text
         GLCD_DisplayString(6, 9, __FI, "Up");
					printf("up\n");
					AD_dbg = 25000;
          LED_On(4);
          break;

        case KBD_DOWN:
					i=5;
          GLCD_DisplayString(6, 9, __FI, "     "); // Clear previous text
          GLCD_DisplayString(6, 9, __FI, "Down");
					printf("down\n");
					AD_dbg = 30000;
          LED_On(1);
          break;

        default:
					LED_On(0);
          break;
      }
    }

    // Print message with AD value every 10 ms
  /*  if (clock_ms) {
      clock_ms = 0;
      printf("AD value: %s\r\n", text);
    }*/
  }