.\traceport_trace\retarget_io.o: C:\Users\ECBME\AppData\Local\Arm\Packs\Keil\ARM_Compiler\1.6.3\Source\retarget_io.c
.\traceport_trace\retarget_io.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\traceport_trace\retarget_io.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\traceport_trace\retarget_io.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\traceport_trace\retarget_io.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdlib.h
.\traceport_trace\retarget_io.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\traceport_trace\retarget_io.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\rt_sys.h
.\traceport_trace\retarget_io.o: .\RTE\_TracePort_Trace\RTE_Components.h
