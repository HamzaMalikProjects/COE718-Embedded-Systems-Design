
#include "cmsis_os.h"                                           // CMSIS RTOS header file
#include "osObjects.h"                      									  // RTOS object definitions
#include <stdio.h>
#include <string.h>
#include "LPC17xx.h"
#include "LED.h"
#include "GLCD.h"
#include <math.h>

#define __DEMO 0
#define __FI 1

// Bit Band Macros used to calculate the alias address at run time
#define ADDRESS(x)    (*((volatile unsigned long *)(x)))
#define BitBand(x, y) 	ADDRESS(((unsigned long)(x) & 0xF0000000) | 0x02000000 |(((unsigned long)(x) & 0x000FFFFF) << 5) | ((y) << 2))
	
volatile unsigned long * bit;

int a=0; 
int b=1; 
int c=0;

/*----------------------------------------------------------------------------
 *      Global Variables
 *---------------------------------------------------------------------------*/
volatile unsigned int memory_access_counter = 0;
volatile unsigned int cpu_mgmt_access_counter = 0;
volatile unsigned int app_interface_counter = 0;
volatile unsigned int device_mgmt_counter = 0;
volatile unsigned int num_of_users = 0;
char logger[100];
osMutexDef(LOGGER_MUTEX);
osMutexId logger_mutex;

/*----------------------------------------------------------------------------
 *      Sample threads
 *---------------------------------------------------------------------------*/

void delay(int time) {
	int x = 0;
	while (x++ < (time*10000)) {}
}

  
void Thread1 (void const *argument); // thread function
void Thread2 (void const *argument); // thread function
void Thread3 (void const *argument); // thread function
void Thread4 (void const *argument); // thread function
void Thread5 (void const *argument); // thread function


osThreadId tid_Thread; // thread id
osThreadDef (Thread1, osPriorityHigh, 1, 0);                   // thread object

osThreadId tid2_Thread; // thread id
osThreadDef (Thread2, osPriorityHigh, 1, 0);                   // thread object

osThreadId tid3_Thread; // thread id
osThreadDef (Thread3, osPriorityAboveNormal, 1, 0);                   // thread object

osThreadId tid4_Thread; // thread id
osThreadDef (Thread4, osPriorityAboveNormal, 1, 0);                   // thread object

osThreadId tid5_Thread; // thread id
osThreadDef (Thread5, osPriorityNormal, 1, 0);                   // thread object

int Init_Thread (void) {
	logger_mutex = osMutexCreate(osMutex(LOGGER_MUTEX));
  tid_Thread = osThreadCreate (osThread(Thread1), NULL);
	tid2_Thread = osThreadCreate (osThread(Thread2), NULL);
	tid3_Thread = osThreadCreate (osThread(Thread3), NULL);
	tid4_Thread = osThreadCreate (osThread(Thread4), NULL);
	tid5_Thread = osThreadCreate (osThread(Thread5), NULL);
  if(!tid_Thread) return(-1);
  if(!tid2_Thread) return(-1);
	if(!tid3_Thread) return(-1);
	if(!tid4_Thread) return(-1);
	if(!tid5_Thread) return(-1);
  return(0);
}

void Thread5 (void const *argument) { // User Interface
		//#ifdef __DEMO
		LED_Off(3);
		osDelay(130000);
		GLCD_DisplayString(8, 0, __FI, "User Int running");
		osDelay(10000);
		LED_On(4);
		osDelay(15);
		//#endif
			num_of_users++;
			osDelay(10000);
			GLCD_DisplayString(9, 0, __FI, "User Int terminated");
			osDelay(10000);
			osThreadTerminate(tid5_Thread);
}

void Thread4 (void const *argument) { // Device Management
		//#ifdef __DEMO
		LED_Off(2);
		osDelay(110000);
		GLCD_DisplayString(6, 0, __FI, "Device Mngr running");
		osDelay(10000);
		LED_On(3);
		osDelay(15);
		//#endif
			osSignalWait(0x03, osWaitForever); // Wait for signal from Application Interface
      strcat(logger, "Ending from Device Management.");
      osSignalSet(tid3_Thread, 0x04); // Signal Application Interface
			osThreadYield();
      device_mgmt_counter++;
			osDelay(15000);
			GLCD_DisplayString(7, 0, __FI, "Device Mngr terminated");
      osDelay(10000);
      osThreadTerminate(tid4_Thread);
}

void Thread3 (void const *argument) { // Application Interface
		//#ifdef __DEMO
		LED_Off(1);
		osDelay(90000);
		GLCD_DisplayString(4, 0, __FI, "App Int running");
		osDelay(10000);
		LED_On(2);
		osDelay(15);
		//#endif
			osMutexWait(logger_mutex, osWaitForever);
      sprintf(logger, "Partial message from Application Interface: ");
      osSignalSet(tid4_Thread, 0x03); // Signal Device Management
			osThreadYield();
      osSignalWait(0x04, osWaitForever); // Wait for signal from Device Management
      app_interface_counter++;
			osDelay(10000);
			GLCD_DisplayString(5, 0, __FI, "App Int terminated");
      osDelay(10000);
      osThreadTerminate(tid3_Thread);
}

void Thread2 (void const *argument) { // CPU Management
		//#ifdef __DEMO
		LED_Off(0);
		osDelay(70000);
		GLCD_DisplayString(2, 0, __FI, "CPU Mngr running");
		osDelay(10000);
		LED_On(1);
		//#endif
			cpu_mgmt_access_counter++;
			// Conditional Execution and barrel shifting scenario
			while (c <= 3) {
				if (a > 10) {
					a--;
				}
				else {
					a++;
				}
				b = a + (b*2);
				c++;
			}
			c = 0;
      osSignalSet(tid_Thread, 0x02); // Signal Memory Management
			osDelay(10000);
			GLCD_DisplayString(3, 0, __FI, "CPU Mngr terminated");
			osDelay(10000);
      osThreadTerminate(tid2_Thread);
}

void Thread1 (void const *argument) { // Memory Management
		//#ifdef __DEMO
		LED_Off(4);
		osDelay(50000);
		GLCD_DisplayString(0, 0, __FI, "Mem Mngr running");
		//osDelay(10000);
		LED_On(0);
		//#endif
		 memory_access_counter++;
     bit = &BitBand(&LPC_GPIO2->FIOPIN, 2);
     osThreadYield();
     osSignalWait(0x02, osWaitForever); // Wait for signal from CPU Management
		 osDelay(100000);
		 GLCD_DisplayString(1, 0, __FI, "Mem Mngr terminated");
     osDelay(10000);
     osThreadTerminate(tid_Thread);
}
