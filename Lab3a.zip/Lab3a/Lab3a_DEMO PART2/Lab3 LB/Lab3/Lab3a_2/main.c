/*----------------------------------------------------------------------------
 * CMSIS-RTOS 'main' function template
 *---------------------------------------------------------------------------*/

#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions
//#include "LED.h"
//#include "GLCD.h"
#define __DEMO 0
#define __FI 1
 
extern int Init_Thread (void);
 

/*
 * main: initialize and start the system
 */
int main (void) {
	osKernelInitialize ();                    // initialize CMSIS-RTOS
	//LED_Init();
	//#ifdef __DEMO
  //GLCD_Init();                               /* Initialize graphical LCD (if enabled */
  //GLCD_Clear(White);                         /* Clear graphical LCD display   */
 // GLCD_SetBackColor(Blue);
 // GLCD_SetTextColor(Black);
 // GLCD_DisplayString(0, 0, __FI, (unsigned char *)" COE718 Hamza Demo  ");
	//GLCD_SetTextColor(White);
  //GLCD_DisplayString(1, 0, __FI, (unsigned char *)"       Lab3a Part 2     ");
//  GLCD_SetBackColor(Red);
//GLCD_SetTextColor(Blue);
	//GLCD_DisplayString(6, 0, __FI, (unsigned char *)"Thread:        ");
	//#endif
 	Init_Thread ();
  osKernelStart ();                         // start thread execution 
	osDelay(osWaitForever);
}
