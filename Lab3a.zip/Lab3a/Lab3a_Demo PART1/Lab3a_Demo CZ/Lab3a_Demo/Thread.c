
#include "cmsis_os.h"   // CMSIS RTOS header file
#include "GLCD.h"
#include <stdio.h>
//#include "LED.h"
#include "LPC17xx.h"  
/*----------------------------------------------------------------------------
 *      Sample threads
 *---------------------------------------------------------------------------*/
unsigned int counta=0;
unsigned int countb=0;
unsigned int countc=0;  
unsigned int status=1;
 
 
const unsigned long led_mask[] = { 1UL<<28, 1UL<<29, 1UL<<31, 1UL<< 2,
                                   1UL<< 3, 1UL<< 4, 1UL<< 5, 1UL<< 6 };
 
 
#define __FI 1 
#define __USE_LCD 0
 
void Thread1 (void const *argument); // thread function
void Thread2 (void const *argument); // thread function
void Thread3 (void const *argument); // thread function



osThreadId tid_Thread; // thread id
osThreadDef (Thread1, osPriorityNormal, 1, 0);                   // thread object

osThreadId tid2_Thread; // thread id
osThreadDef (Thread2, osPriorityNormal, 1, 0);                   // thread object

osThreadId tid3_Thread; // thread id
osThreadDef (Thread3, osPriorityNormal, 1, 0); 

char text[16]; 

void delay(int ms){
	int count;
	for(count = 0; count < ms; count++)
	{
			count++;
	} 
}	



int Init_Thread (void) {
	
	  LPC_GPIO1->FIODIR |= 0xB0000000;           /* LEDs on PORT1 are output      */
		LPC_GPIO2->FIODIR |= 0x0000007C;           /* LEDs on PORT2 are output      */
	    #ifdef __USE_LCD
        GLCD_Init();                               /* Initialize graphical LCD (if enabled)*/
				
				//LED_Init();
        GLCD_Clear(White);                         /* Clear graphical LCD display   */
        GLCD_SetBackColor(Blue);
        GLCD_SetTextColor(Red);
        GLCD_DisplayString(0, 0, __FI, "  COE718 Hamza Lab3a   ");
        GLCD_SetTextColor(White);
        GLCD_DisplayString(1, 0, __FI, "      ");
        GLCD_DisplayString(2, 0, __FI, "         Thread.c         ");
        GLCD_SetBackColor(White);
        GLCD_SetTextColor(Black);
    #endif


  tid_Thread = osThreadCreate (osThread(Thread1), NULL);
	tid2_Thread = osThreadCreate (osThread(Thread2), NULL);
	tid3_Thread = osThreadCreate (osThread(Thread3), NULL);
  if(!tid_Thread) return(-1);
  
  return(0);
}

void Thread3 (void const *argument) {
	  for(;;) {
    countc++; 
		if(status != 3){
		status = 3;
		
		LPC_GPIO1->FIOCLR =  led_mask[1];
		LPC_GPIO1->FIOCLR =  led_mask[0];
		LPC_GPIO1->FIOSET =  led_mask[2];
		GLCD_ClearLn(8,1);
		
		GLCD_DisplayString(8,0, __FI, " Thread 3 going");
		}
		
		if(countc == 0x00999990){
			GLCD_DisplayString(4,0, __FI, " Thread 3 Done");
			LPC_GPIO1->FIOCLR =  led_mask[2];
			GLCD_ClearLn(8,1);
			osThreadTerminate(tid3_Thread);
			
  	}
  }
}

void Thread2 (void const *argument) {
	  for(;;) {
    countb++;
		if(status != 2){

		LPC_GPIO1->FIOCLR =  led_mask[0];
		LPC_GPIO1->FIOCLR =  led_mask[2];
		LPC_GPIO1->FIOSET =  led_mask[1];
		status = 2;
		GLCD_ClearLn(8,1);
		
		GLCD_DisplayString(8,0, __FI, " Thread 2 going");
		}
		
  	if(countb == 0x03200050){
			GLCD_DisplayString(5,0, __FI, " Thread 2 Done");
			LPC_GPIO1->FIOCLR =  led_mask[1];
			GLCD_ClearLn(8,1);
			osThreadTerminate(tid2_Thread);
			
		}
  }
}

void Thread1 (void const *argument) {
	 for(;;) {
   counta++;
	 if(status != 1){
	 LPC_GPIO1->FIOCLR =  led_mask[1];
	 LPC_GPIO1->FIOCLR =  led_mask[2];
	 LPC_GPIO1->FIOSET =  led_mask[0];
	 status = 1;
	 GLCD_ClearLn(8,1);
	 
	 GLCD_DisplayString(8,0, __FI, " Thread 1 going");
	 }
	 if(counta == 0x02800010){
		 GLCD_DisplayString(6,0, __FI, " Thread 1 Done");
		 LPC_GPIO1->FIOCLR =  led_mask[0];
		 GLCD_ClearLn(8,1);
		 osThreadTerminate(tid_Thread);
		 
	 }
     
  }
}
