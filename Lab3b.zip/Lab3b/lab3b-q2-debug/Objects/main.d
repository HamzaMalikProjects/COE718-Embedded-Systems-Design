.\objects\main.o: main.c
.\objects\main.o: osObjects.h
.\objects\main.o: C:\Users\Colin Page\AppData\Local\Arm\Packs\ARM\CMSIS\5.9.0\CMSIS\RTOS\RTX\INC\cmsis_os.h
.\objects\main.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\main.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\main.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\math.h
.\objects\main.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\main.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\main.o: C:\Users\Colin Page\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\LPC17xx.h
.\objects\main.o: C:\Users\Colin Page\AppData\Local\Arm\Packs\ARM\CMSIS\5.9.0\CMSIS\Core\Include\core_cm3.h
.\objects\main.o: C:\Users\Colin Page\AppData\Local\Arm\Packs\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_version.h
.\objects\main.o: C:\Users\Colin Page\AppData\Local\Arm\Packs\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\main.o: C:\Users\Colin Page\AppData\Local\Arm\Packs\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\main.o: C:\Users\Colin Page\AppData\Local\Arm\Packs\ARM\CMSIS\5.9.0\CMSIS\Core\Include\mpu_armv7.h
.\objects\main.o: C:\Users\Colin Page\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\system_LPC17xx.h
